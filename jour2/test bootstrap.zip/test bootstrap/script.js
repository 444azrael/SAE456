// script.js
$(document).ready(function () {
  $(window).scroll(function () {
      $('.parallax').css('background-position-y', -(scrollTop * 0.3) + 'px');
  });
});

// script.js
document.addEventListener('DOMContentLoaded', function () {
  window.addEventListener('scroll', function () {
      var scrollTop = window.scrollY;
      var navbar = document.querySelector('.navbar');

      if (scrollTop === 0) {
          navbar.classList.add('fixed-top', 'transparent-bg');
      } else {
          navbar.classList.remove('fixed-top', 'transparent-bg');
      }
  });
});
